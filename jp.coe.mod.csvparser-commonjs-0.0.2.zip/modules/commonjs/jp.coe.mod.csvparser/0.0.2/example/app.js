
var csv = require('jp.coe.mod.CSVParser');
csv.getFileToJSON("foo.csv");
